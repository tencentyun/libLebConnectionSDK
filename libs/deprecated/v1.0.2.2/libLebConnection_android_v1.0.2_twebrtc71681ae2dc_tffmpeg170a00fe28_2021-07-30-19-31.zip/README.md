# 快直播ffmpeg plugin(lebconnection)说明


## SDK接口说明：

// 创建快直播连接
LEB_EXPORT_API LebConnectionHandle* OpenLebConnection(void* context, LebLogLevel loglevel);

// 注册回调函数
LEB_EXPORT_API void RegisterLebCallback(LebConnectionHandle* handle, const LebCallback* callback);

// 开始连接，内部完成信令后，直接建联拉流
LEB_EXPORT_API void StartLebConnection(LebConnectionHandle* handle, LebConfig config);

// 停止连接
LEB_EXPORT_API void StopLebConnection(LebConnectionHandle* handle);

// 关闭连接
LEB_EXPORT_API void CloseLebConnection(LebConnectionHandle* handle);

// 播放过程中查询统计数据，onStatsInfo异步回调输出
LEB_EXPORT_API void GetStats(LebConnectionHandle* handle);

 数据定义详见头文件leb_connection_api.h


## ffmpeg工作流程说明:

 input url webrtc://domain/path/streamid?txTime=xxxx&txSecret=xxxx
 ====>
 webrtc demuxer
 ====>
 output avpacket


