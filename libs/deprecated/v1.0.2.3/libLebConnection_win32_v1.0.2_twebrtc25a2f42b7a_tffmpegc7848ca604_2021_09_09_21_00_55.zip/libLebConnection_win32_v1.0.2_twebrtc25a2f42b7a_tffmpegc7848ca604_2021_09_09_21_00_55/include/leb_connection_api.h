// Copyright (c) 2020 Tencent. All rights reserved.


#ifndef LEB_CONNECTION_API_H_
#define LEB_CONNECTION_API_H_

#include <stdint.h>


#ifdef __cplusplus
extern "C" {
#endif

#if defined(_WIN32)
#define LEB_EXPORT_API __declspec(dllexport)
#else
#define LEB_EXPORT_API __attribute__((visibility("default")))
#endif

typedef enum LebVideoCodecType {
  kNoVideo = -1,
  kH264,
  kH265,
} LebVideoCodecType;

typedef enum LebAudioCodecType {
  kNoAudio = -1,
  kOpus,
  kAac,
} LebAudioCodecType;

typedef enum LebMetaDataType {
  kAudio,
  kVideo,
  kData,
} LebMetaDataType;

typedef enum LebNetState {
  // 正在连接中
  kConnecting,
  // 连接成功
  kConnected,
  // 当前已经断网，正在尝试重新连接
  kDisconnected,
  // 重连失败，网络不可恢复
  kConnectFailed,
  // 客户主动关闭连接
  kConnectClosed,
} LebNetState;

typedef enum LebLogLevel {
  kDebug,
  kInfo,
  kWarning,
  kError,
} LebLogLevel;

typedef enum LebSdpType {
  kOffer,
  kAnswer,
} LebSdpType;

typedef struct LebSdpInfo {
  LebSdpType type;
  const char* sdp;
} LebSdpInfo;

typedef struct LebVideoInfo {
  LebVideoCodecType codec_type;
  uint8_t extra_data[4096];
  size_t extra_size;
} LebVideoInfo;

typedef struct LebAudioInfo {
  LebAudioCodecType codec_type;
  int32_t sample_rate;
  int32_t num_channels;
} LebAudioInfo;

typedef struct LebEncodedVideoFrame {
  LebVideoCodecType codec_type;
  const uint8_t* data;
  size_t size;
  int64_t pts;
  int64_t dts;
  int32_t output_delay_ms;
} LebEncodedVideoFrame;

typedef struct LebEncodedAudioFrame {
  LebAudioCodecType codec_type;
  const uint8_t* data;
  size_t size;
  int64_t dts;
  int64_t pts;
  int32_t sample_rate;
  int32_t num_channels;
  int32_t output_delay_ms;
} LebEncodedAudioFrame;

typedef struct LebMetaData {
  const uint8_t* data;
  size_t size;
  LebMetaDataType type;
} LebMetaData;

typedef struct LebStats {
  // network
  int32_t rtt_ms;
  // 信令服务器 IP
  const char* signal_server_ip;
  // 信令服务器域名解析耗时
  int32_t signal_dns_cost_ms;
  // 数据服务器 IP
  const char* data_server_ip;
  // 从开始拉流到收到首个视频帧的时间
  int32_t first_video_received_cost_ms;
  // 从开始拉流到收到首个音频帧的时间
  int32_t first_audio_received_cost_ms;

  // video
  uint32_t video_packets_received;
  uint64_t video_bytes_received;
  int32_t video_packets_lost;
  uint32_t video_nack_count;

  // audio
  uint32_t audio_packets_received;
  uint64_t audio_bytes_received;
  int32_t audio_packets_lost;
  uint32_t audio_nack_count;
} LebStats;

typedef enum LebErrorCode {
  kNone = 0,
  // remote address解析出错
  kResolve_error,
  // stream url格式出错
  kScheme_error,
  // stream url鉴权失败
  kAuth_error,
  // stream不存在
  kNotFound_error,
  // 未知错误
  kUnknow_error,
} LebErrorCode;

typedef void (*OnLogInfo)(void* context, const char* tag, LebLogLevel, const char* message);
typedef void (*OnVideoInfo)(void* context, LebVideoInfo info);
typedef void (*OnAudioInfo)(void* context, LebAudioInfo info);
typedef void (*OnEncodedVideo)(void* context, LebEncodedVideoFrame video_frame);
typedef void (*OnEncodedAudio)(void* context, LebEncodedAudioFrame audio_frame);
typedef void (*OnMetaData)(void* context, LebMetaData data);
typedef void (*OnStatsInfo)(void* context, LebStats stats);
typedef void (*OnError)(void* context, LebErrorCode error);

typedef struct LebCallback {
  // 日志回调
  OnLogInfo onLogInfo;
  // 视频信息回调
  OnVideoInfo onVideoInfo;
  // 音频信息回调
  OnAudioInfo onAudioInfo;
  // 视频数据回调
  OnEncodedVideo onEncodedVideo;
  // 音频数据回调
  OnEncodedAudio onEncodedAudio;
  // MetaData回调
  OnMetaData onMetaData;
  // 统计信息回调
  OnStatsInfo onStatsInfo;
  // 错误回调
  OnError onError;
} LebCallback;

typedef struct LebConfig {
    // 码流地址，如: "webrtc://5664.liveplay.myqcloud.com/live/5664_harchar1"，给内部udp信令用
    const char* stream_url;
    // 信令ip或域名，默认为"webrtc.liveplay.myqcloud.com"
    const char* signal_address;
    // 视频开关
    int receive_video;
    // 音频开关
    int receive_audio;
    // 是否开启 AAC，开启时CDN下发原始流，否则默认音频转码成Opus
    int enable_aac;
    // FlexFEC 开关
    int enable_flex_fec;
    // 统计回调周期，内部默认5秒
    int stats_period_ms;
    // 是否开启音频补包
    int enable_audio_plc;
} LebConfig;

typedef struct LebConnectionHandle {
    void* context;
    void* internal_handle;
    LebConfig config;
    LebCallback callback;
} LebConnectionHandle;

// 创建快直播连接
LEB_EXPORT_API LebConnectionHandle* OpenLebConnection(void* context, LebLogLevel loglevel);

// 注册回调函数
LEB_EXPORT_API void RegisterLebCallback(LebConnectionHandle* handle, const LebCallback* callback);

// 开始连接，内部完成信令后，直接建联拉流
LEB_EXPORT_API void StartLebConnection(LebConnectionHandle* handle, LebConfig config);

// 停止连接
LEB_EXPORT_API void StopLebConnection(LebConnectionHandle* handle);

// 关闭连接
LEB_EXPORT_API void CloseLebConnection(LebConnectionHandle* handle);

// 播放过程中查询统计数据，onStatsInfo异步回调输出
LEB_EXPORT_API void GetStats(LebConnectionHandle* handle);

#ifdef __cplusplus
}
#endif

#endif  // LEB_CONNECTION_API_H_
