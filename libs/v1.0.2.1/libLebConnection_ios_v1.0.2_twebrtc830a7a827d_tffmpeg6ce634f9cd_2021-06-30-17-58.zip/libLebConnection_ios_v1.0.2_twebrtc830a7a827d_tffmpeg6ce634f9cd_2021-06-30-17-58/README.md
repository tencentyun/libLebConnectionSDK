# 快直播ffmpeg plugin(lebconnection)说明


## SDK接口说明：

 // 创建快直播连接 
 WEBRTC_EXPORT_API LebConnectionHandle* OpenLebConnection(void* context, LebLogLevel loglevel);

 // 开始连接，内部完成信令后，直接建联拉流
 WEBRTC_EXPORT_API void StartLebConnection(LebConnectionHandle* handle, LebConfig config);

 // 开始信令，回调onOfferCreated输出offer sdp，通过http交互获取answer sdp
 WEBRTC_EXPORT_API void CreateOffer(LebConnectionHandle* handle, LebConfig config);

 // 设置获取的answer sdp，开始建联拉流
 WEBRTC_EXPORT_API void SetRemoteSDP(LebConnectionHandle* handle, LebSdpInfo info);

 // 停止连接
 WEBRTC_EXPORT_API void StopLebConnection(LebConnectionHandle* handle);

 // 关闭连接
 WEBRTC_EXPORT_API void CloseLebConnection(LebConnectionHandle* handle);

 // 播放过程中查询统计数据，onStatsInfo异步回调输出
 WEBRTC_EXPORT_API void GetStats(LebConnectionHandle* handle);

 // 注册日志回调函数
 WEBRTC_EXPORT_API void RegisterLogInfoCallback(LebConnectionHandle* handle, OnLogInfo callback);

 // 注册sdp回调函数，获取offer sdp
 WEBRTC_EXPORT_API void RegisterSdpInfoCallback(LebConnectionHandle* handle, OnSdpInfo callback);

 // 注册视频信息回调函数，获取视频信息
 WEBRTC_EXPORT_API void RegisterVideoInfoCallback(LebConnectionHandle* handle, OnVideoInfo callback);

 // 注册音频信息回调函数，获取音频信息
 WEBRTC_EXPORT_API void RegisterAudioInfoCallback(LebConnectionHandle* handle, OnAudioInfo callback);

 // 注册视频数据回调函数，获取视频帧裸数据
 WEBRTC_EXPORT_API void RegisterVideoDataCallback(LebConnectionHandle* handle, OnEncodedVideo callback);

 // 注册音频数据回调函数，获取音频帧裸数据
 WEBRTC_EXPORT_API void RegisterAudioDataCallback(LebConnectionHandle* handle, OnEncodedAudio callback);

 // 注册MetaData回调函数，获取MetaData数据
 WEBRTC_EXPORT_API void RegisterMetaDataCallback(LebConnectionHandle* handle, OnMetaData callback);

 // 注册统计回调函数，获取统计数据
 WEBRTC_EXPORT_API void RegisterStatsInfoCallback(LebConnectionHandle* handle, OnStatsInfo callback);

 数据定义详见头文件leb_connection_api.h


## ffmpeg工作流程说明:

 input url webrtc://domain/path/streamid?txTime=xxxx&txSecret=xxxx
 ====>
 webrtc demuxer
 ====>
 output avpacket


